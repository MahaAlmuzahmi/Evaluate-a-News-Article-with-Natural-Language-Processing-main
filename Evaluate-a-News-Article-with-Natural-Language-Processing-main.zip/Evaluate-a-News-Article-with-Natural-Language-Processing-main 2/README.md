
# Evaluate a news article with Natural Language Processing

# Technologies and Languages Used:

- Backend-Server:
  - ExpressJS(NodeJS)
  - Async/Await
- UI (Front-end):
  - Sass
  - HTML
- Tools:
  - Webpack
  - Git version Control System
  - Github
- Testing:
  - Jest

## Interactions

The page built for this project is a simple one. It has a form with a single filed which receives an input. This input is checked for valid url. A helpful error message is displayed for invalid url. If the url is valid, then an api call is performed and the result displayed on the page.

### Home page

![](./src/client/img/p1.png)

### API response - valid URL
![](./src/client/img/p2.png)

### Invalid URL message

![](./src/client/img/p3.png)

## Run project

Below shows how to run in development and production mode.

### Download Dependencies

`npm install`

### run in development mode

To start the webpack dev server at port 8000

` $ npm run build-dev` 

Start back-end serve
`npm run start` 

### run in production mode

Generate the dist files and then start server at port 8000

` $ npm run build-prod` 

` $ npm run start` 



## API

The project uses Semantic Text Analysis SDKs from [Meaning Cloud](https://learn.meaningcloud.com/developer/sentiment-analysis/2.1/doc), which provides a powerful and flexible AI-driven content analysis solutions.


## Testing

Testing is done with Jest. To run test, use the command

`npm run test` 

![](./src/client/img/p4.png)
