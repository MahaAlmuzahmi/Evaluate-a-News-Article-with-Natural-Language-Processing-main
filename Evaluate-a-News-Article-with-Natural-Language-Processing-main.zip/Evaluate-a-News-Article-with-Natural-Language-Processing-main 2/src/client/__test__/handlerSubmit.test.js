
const {handleSubmit} = require("../js/handleSubmit")

describe('handleSubmit is successful', ()=> {
    it('returns something', () => {
        expect(handleSubmit).toBeDefined();
    })
})